package PUNTO2;

import java.util.Scanner;


public class CODIGO2 {
    
    
    
    public static void main(String[] args) {
                 
        double saldoInicio;               
        double abonos;               
        double totalDeduccionesMes;               
        double limiteCredito; 
        
        double nuevoSaldo = 0;
          
        Scanner entrada = new Scanner(System.in);
        
        
        System.out.println("Escriba su saldoInicial: ");           
        saldoInicio = entrada.nextDouble();              
                
        System.out.println("Escriba el abono : ");       
        abonos = entrada.nextDouble();              
                
        System.out.println("Escriba el totalDeduccionesDelMes : ");        
        totalDeduccionesMes = entrada.nextDouble();              

        System.out.println("Escriba el limite de credito para el cliente: ");      
        limiteCredito = entrada.nextDouble();              
                
      
        nuevoSaldo = saldoInicio + abonos - totalDeduccionesMes;
        
        if( totalDeduccionesMes > limiteCredito){
            
            System.out.println(" Usted ha excedido el limite de creditos  ");
        }else{
            
            System.out.println("Usted no ha excedido el limite de creditos otorgados ");
        }
        
        System.out.println(" El nuevo saldo es de : " +nuevoSaldo);
        
    }
}
