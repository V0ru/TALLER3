

package PUNTO1;

import java.util.Scanner;


public class CODIGO1 {
    static String A []= new String[20];
    static double B []= new double[20];
    static int C []= new int[20];
    static int D []= new int [20];
    static String op="si";
    static int suma=0;
    static int i, cont=0;;
    public static void main(String[] args) {
        capturarDatos();
        mostrar();   
    }
   public static void capturarDatos(){
      Scanner scanner = new Scanner(System.in);
     do{
         System.out.println("Escriba el codigo del producto: ");
         A[i]=scanner.nextLine();
         System.out.println("Escriba el valor del producto: ");
         B[i]=scanner.nextDouble();
         System.out.println("Escriba la cantidad de productos: ");
         C[i]=scanner.nextInt();
         scanner.nextLine();
         System.out.println("Quiere ingresar otro producto? si/no");
         op=scanner.nextLine();
         if(op.toUpperCase().equals("NO")){
             op="NO";
         }
          i++;
    }while(op!="NO");  
   }
   public static int productoVendido(){
       for(i=0; i<20; i++){
           suma+=C[i];
       }
       return suma;
   }
    public static long ingresoDiario(){
        for(i=0; i<20; i++){
           suma+=B[i];
       }
        return suma;
    }
    public static int productoMasVendido(){
        int mayor = C[0];
        int pMayor=0;
    for(int i = 1; i < 20; ++i)
    {
        if(C[i] > mayor)
        {
            mayor = C[i];
            pMayor = i;
        }
    }
    return mayor;
    }
    public static long productoMasCostoso(){
            int mayor = (int) B[0];
    for(int i = 1; i < 20; ++i)
    {
        if(B[i] > mayor)
        {
            mayor = (int) B[i];
            cont++;
        }
    }  
    return mayor;
    }
    public static void mostrar(){
        System.out.println("Total productos vendidos en el día:"+productoVendido() );
        System.out.println("Total ingresos por ventas del día:"+ingresoDiario() );
        System.out.println("El producto más vendido:"+"codigo del producto"
                + ": "+A[cont]+" valor de la venta: "+B[cont]
                +" cantidad de productos: "+productoMasVendido() );
        System.out.println("El producto más costoso vendido:" + productoMasCostoso());
    }
}