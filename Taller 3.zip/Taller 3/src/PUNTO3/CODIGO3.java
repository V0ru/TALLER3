package punto3;

import java.util.Scanner;

public class CODIGO3 {
    public static void main(String[] args) {
        Scanner leer=new Scanner(System.in);
        double suma=0;
        double sumaa=0;
        double pago_sem=0;
        double pago_sem2=0;
        int [] beneficio=new int[7];
        for (int i = 0; i < 7; i++) {
            System.out.println("Escriba su ganancia del dia "+(i+1)+" :");
            beneficio[i]=leer.nextInt();
        }
        for (int g = 0; g < 7 ; g++) {
            suma += beneficio[g];
            
        }
     
        if (suma>3000 && suma<5000){
            double multi;
            multi=(suma*0.05);
            pago_sem=suma+multi+200;
            System.out.println("Si usted es empleado de la categoria A, su pago semanal es : "+pago_sem);            
        }
        else if (suma>=5000 && suma<= 7000){
            double multi2=suma*0.07;
            pago_sem=suma+multi2*200;
            System.out.println("Si usted es empleado de la categoria A, su pago semanal es  : "+pago_sem);    
        }
        else if (suma>7000){
            double multi3=suma*0.010;
            pago_sem=suma+multi3+200;
            System.out.println("Si usted es empleado de la categoria A, su pago semanal es : "+pago_sem);
        }
        
        sumaa=suma;
        if(sumaa>5000 & sumaa<10000){
            double multi4=sumaa*0.07;
            pago_sem2=sumaa+multi4*200;
            System.out.println("Si usted es empleado de la categoria B, su pago semanal es : "+pago_sem2);
        }
        else if (sumaa>=10000 & sumaa<=15000){
            double multi5=sumaa*0.010;
            pago_sem2=sumaa+multi5+200;

            System.out.println("Si usted es empleado de la categoria B, su pago semanal es : "+pago_sem2);
        }
        else if (sumaa>15000){
            double mutli6=sumaa*0.013;
            pago_sem2=sumaa+mutli6+200;
            System.out.println("Si usted es empleado de la categoria B, su pago semanal es : "+pago_sem2);
        }

        
   
  
    }
    
}

