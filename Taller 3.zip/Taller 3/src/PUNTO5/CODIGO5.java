package PUNTO5;

public class CODIGO5 {
    public static void main(String args[]){
        int candida[][];
        candida= new int[5][4];
        candida[0][0] = 194;
	candida[0][1] = 48;
	candida[0][2] = 206;
	candida[0][3] = 45;
	candida[1][0] = 180;
        candida[1][1] = 20;
	candida[1][2] = 320;
	candida[1][3] = 16;
	candida[2][0] = 221;
	candida[2][1] = 90;
	candida[2][2] = 140;
	candida[2][3] = 20;
	candida[3][0] = 432;
	candida[3][1] = 50;
	candida[3][2] = 821;
	candida[3][3] = 14;
	candida[4][0] = 820;
	candida[4][1] = 61;
	candida[4][2] = 946;
	candida[4][3] = 18;
        System.out.println("Columna   "+"Candidato A   "+"Candidato B   "+"Candidato C   "+"Candidato D   ");
        int colu=0;
        int i=0;
        double suma_total=0;
        double suma=0,suma2=0,suma3=0,suma4=0;
        for (i=1;i<6;i++){
            colu=colu+1;
            System.out.println("    "+"|"+colu+"|"+"         "+"|"+candida[i-1][0]+"|"+"           "+"|"+candida[i-1][1]+"|"+"           "+"|"+candida[i-1][2]+"|"+"           "+"|"+candida[i-1][3]+"|");
            suma=candida[i-1][0];
            suma2+=candida[i-1][1];
            suma3+=candida[i-1][2];
            suma4+=candida[i-1][3];
            suma_total=suma+suma2+suma3+suma4;
        }
        System.out.println("LA SUMA TOTAL ES: "+suma_total);
        System.out.println(" LA SUMA DE LOS VOTOS DEL CANDIDATO A ES DE : "+suma);
        System.out.println(" LA SUMA DE LOS VOTOS DEL CANDIDATO B ES DE : "+suma2);
        System.out.println(" LA SUMA DE LOS VOTOS DEL CANDIDATO C ES DE : "+suma3);
        System.out.println(" LA SUMA DE LOS VOTOS DEL CANDIDATO D ES DE : "+suma4);
        System.out.println("El CANDIDATO CON MAS VOTOS FUE EL 3 CON : "+suma3+" votos ");
        double porcentaje1,porcentaje2,porcentaje3,porcentaje4;
        porcentaje1=suma*100/suma_total;
        porcentaje2=suma2*100/suma_total;
        porcentaje3=suma3*100/suma_total;
        porcentaje4=suma4*100/suma_total;
        System.out.printf("EL PORCENTAJE DE VOTOS DEL CANDIDATO A ES : %.2f %n",porcentaje1);
        System.out.printf("EL PORCENTAJE DE VOTOS DEL CANDIDATO B ES : %.2f %n",porcentaje2);
        System.out.printf("EL PORCENTAJE DE VOTOS DEL CANDIDATO C ES : %.2f %n",porcentaje3);
        System.out.printf("EL PORCENTAJE DE VOTOS DEL CANDIDATO D ES : %.2f %n",porcentaje4);
        System.out.println("EL GANADOR DE LAS VOTACIONES HA SIDO EL CANDITADO C ");
        System.out.println("CON UNA CANTIDAD DE VOTOS DE: "+suma3);
        System.out.printf("CON UN PORCENTAJE DEL: %.2f %n",porcentaje3);
        for (int x = 0; x < candida.length; x++) {
            int sumas = 0;
            for (int b = 0; b < candida[x].length; b++) {
                System.out.printf("%d ", candida[x][b]);
                sumas += candida[x][b];
            }
            System.out.printf("= %d %n", sumas);
        }   System.out.println("la comuna  con mas votos es la 5");
 
    }
}      
